-- All songs in increasing order of tempo.
SELECT name FROM songs ORDER BY tempo;
