-- All songs in the database.
SELECT name FROM songs;
