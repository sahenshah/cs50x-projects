SELECT COUNT(*) AS num_movies_with_rating_10
FROM ratings
WHERE rating = 10.0;
